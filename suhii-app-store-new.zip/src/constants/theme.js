export const COLORS = {
    primary: '#1a1a1a', // Màu đen chủ đạo (không dùng #000 tuyệt đối để đỡ chói)
    secondary: '#4d4d4d', // Xám đậm
    white: '#FFFFFF',
    lightGray: '#f0f2f5',
    success: '#28a745',
    danger: '#D32F2F',
    warning: '#f39c12',
};